let cards = [
    { id: 1, imagePath: "cardimages/A1.png", altText: "A1"},
    { id: 2, imagePath: "cardimages/A2.png", altText: "A2"},
    { id: 3, imagePath: "cardimages/A3.png", altText: "A3"},
    { id: 4, imagePath: "cardimages/A4.png", altText: "A4"},
    { id: 5, imagePath: "cardimages/A5.png", altText: "A5"},
    { id: 6, imagePath: "cardimages/A6.png", altText: "A6"},
    { id: 7, imagePath: "cardimages/A7.png", altText: "A7"},
    { id: 8, imagePath: "cardimages/A8.png", altText: "A8"},
    { id: 9, imagePath: "cardimages/A9.png", altText: "A9"},
];

const questions = [
    { id: 1, text: ["<ruby>赤<rt>あか</rt></ruby>は", "<ruby>青<rt>あお</rt></ruby>より", "１<ruby>多<rt>おお</rt></ruby>い"]},
    { id: 2, text: ["<ruby>赤<rt>あか</rt></ruby>は","<ruby>青<rt>あお</rt></ruby>より","１<ruby>少<rt>すく</rt></ruby>ない"]},
    { id: 3, text: ["<ruby>赤<rt>あか</rt></ruby>は","<ruby>青<rt>あお</rt></ruby>より","２<ruby>多<rt>おお</rt></ruby>い"]},
    { id: 4, text: ["<ruby>赤<rt>あか</rt></ruby>は","<ruby>青<rt>あお</rt></ruby>より","２<ruby>少<rt>すく</rt></ruby>ない"]},
    { id: 5, text: ["<ruby>赤<rt>あか</rt></ruby>は","<ruby>青<rt>あお</rt></ruby>より","３<ruby>多<rt>おお</rt></ruby>い"]},
    { id: 6, text: ["<ruby>赤<rt>あか</rt></ruby>は","<ruby>青<rt>あお</rt></ruby>より","３<ruby>少<rt>すく</rt></ruby>ない"]},
    { id: 7, text: ["<ruby>赤<rt>あか</rt></ruby>は","<ruby>青<rt>あお</rt></ruby>より","４<ruby>多<rt>おお</rt></ruby>い"]},
    { id: 8, text: ["<ruby>赤<rt>あか</rt></ruby>は","<ruby>青<rt>あお</rt></ruby>より","４<ruby>少<rt>すく</rt></ruby>ない"]},
    { id: 9, text: ["<ruby>赤<rt>あか</rt></ruby>は","<ruby>青<rt>あお</rt></ruby>と","<ruby>等<rt>ひと</rt></ruby>しい"]},
    { id: 10, text: ["<ruby>青<rt>あお</rt></ruby>は","<ruby>赤<rt>あか</rt></ruby>より","１<ruby>少<rt>すく</rt></ruby>ない"]},
    { id: 11, text: ["<ruby>青<rt>あお</rt></ruby>は","<ruby>赤<rt>あか</rt></ruby>より","１<ruby>多<rt>おお</rt></ruby>い"]},
    { id: 12, text: ["<ruby>青<rt>あお</rt></ruby>は","<ruby>赤<rt>あか</rt></ruby>より","２<ruby>少<rt>すく</rt></ruby>ない"]},
    { id: 13, text: ["<ruby>青<rt>あお</rt></ruby>は","<ruby>赤<rt>あか</rt></ruby>より","２<ruby>多<rt>おお</rt></ruby>い"]},
    { id: 14, text: ["<ruby>青<rt>あお</rt></ruby>は","<ruby>赤<rt>あか</rt></ruby>より","３<ruby>少<rt>すく</rt></ruby>ない"]},
    { id: 15, text: ["<ruby>青<rt>あお</rt></ruby>は","<ruby>赤<rt>あか</rt></ruby>より","３<ruby>多<rt>おお</rt></ruby>い"]},
    { id: 16, text: ["<ruby>青<rt>あお</rt></ruby>は","<ruby>赤<rt>あか</rt></ruby>より","４<ruby>少<rt>すく</rt></ruby>ない"]},
    { id: 17, text: ["<ruby>青<rt>あお</rt></ruby>は","<ruby>赤<rt>あか</rt></ruby>より","４<ruby>多<rt>おお</rt></ruby>い"]},
    { id: 18, text: ["<ruby>青<rt>あお</rt></ruby>は","<ruby>赤<rt>あか</rt></ruby>と","<ruby>等<rt>ひと</rt></ruby>しい"]},
];
//一周終わってパターン変化

let ImagePath = ["A", "B", "C", "D", "E", "F", "G", "H"];

let activeCard = null;
let currentQuestion = null;
let availableQuestions = null;
let extension = ".jpg";
let score = 0;
let ct = 0;

let list = null;

// "red" "blue" "all"
// let questionPattern = null;
let questionPattern = "red";

function changeCardsImagePath(cardPattern){
    for(let i =  0; i < cards.length; i++){
        const imageNum = (i+1).toString();
        const imagePath = "cardimages/" + cardPattern + imageNum + extension;
        cards[i].imagePath = imagePath;
        cards[i].altText = cardPattern + imageNum;
    }
}

changeCardsImagePath("A");
// changeCardsImagePath("B");
// changeCardsImagePath("C");
// changeCardsImagePath("D");
// changeCardsImagePath("E");
// changeCardsImagePath("F");
// changeCardsImagePath("G");
// changeCardsImagePath("H");


function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}
const modal = document.getElementById("modal");

function openModal(message,waitingTime=1000) {
    modalMessage = document.getElementById("modal-message");
    modalMessage.innerHTML = message;
    modal.style.display = "block";
    setTimeout(closeModal, waitingTime);
}
function closeModal() {
    modal.style.display = "none";
}
let cardid = null;
function createCardElement(card) {
    const cardElement = document.createElement("div");
    cardElement.className = "card";
    //cardElement.id = card.id;
    cardElement.classList.add("grid-item");
    // 画像要素を作成
    const image = document.createElement("img");
    // 画像のパスを設定
    image.src = card.imagePath; // 画像ファイルのパスを設定
    image.style.borderColor = 'snow';
    // 画像の代替テキストを設定
    image.alt = card.altText;
    // ランダムな回転角度を生成（-30度から+30度まで）
    //const randomRotation = Math.floor(Math.random() * 61) - 30;
    // 画像にランダムな回転を適用
    //image.style.transform = `rotate(${randomRotation}deg)`;
    // 画像をカードに追加
    cardElement.appendChild(image);
    // cardがクリックされたとき
    cardElement.addEventListener("click", () => {
        if(image.style.borderColor === 'snow'){
            if (cardid !== null){
                cardid.style.borderColor ='snow';
            }
            image.style.borderColor = 'red';  
            cardid = image;
        } else if (image.style.borderColor === 'red'){
            if (card.id === currentQuestion.id % 9) {
                //showResult("正解");
                openModal("正解！");
                playSound("sounds/shakin.mp3");
                score++;
                //document.getElementById("score").textContent = score.toString();
            } else {
                //showResult("不正解");
                openModal("おてつき");
                playSound("sounds/pafu.mp3")
            }
        
        // closemodalと同じタイミング
        setTimeout(refleshQuestion, 1010);
        }
    }    
        
    );
    return cardElement;
}

// sound tag is "<audio id = "myAudio">"
function playSound(soundPath) {
    const myAudio = document.getElementById("myAudio");
    myAudio.src = soundPath;
    myAudio.play();
}
function refleshQuestion(){
    if(ct === 10){
        openModal("問題終了！！<br>あなたの得点は、"+score+"　点でした！！！",5000);
        ct = 0;
        score = 0;
    }
    shuffle(cards);
    if(questionPattern === "red"){
        availableQuestions = questions.slice(0, 10);
    }else if(questionPattern === "blue"){
        availableQuestions = questions.slice(10, 19);
    }else{
        // availableQuestions  "all"
        availableQuestions = questions;
    }
    // shuffle(availableQuestions);
    const arrayLength = availableQuestions.length;
    // 1 から arrayLength までの整数をランダムに生成
    const randomIndex = Math.floor(Math.random() * arrayLength);
    currentQuestion = availableQuestions[randomIndex];
    document.getElementById("question").innerHTML = currentQuestion.text[0];
    setTimeout(function(){document.getElementById("question").innerHTML += currentQuestion.text[1];}, 1000);
    setTimeout(function(){document.getElementById("question").innerHTML += currentQuestion.text[2];}, 2000);
    document.getElementById("score").textContent = score.toString()+"/10";
    const cardsContainer = document.getElementById("cards");
    cardsContainer.innerHTML = "";
    cards.forEach((card) => {
        cardsContainer.appendChild(createCardElement(card));
    });
    ct++;
}
function initGame() {
    refleshQuestion();
}

initGame();